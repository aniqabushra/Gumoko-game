package learn.gomoku;

import learn.gomoku.game.Gomoku;
import learn.gomoku.game.Result;
import learn.gomoku.players.*;
import learn.gomoku.game.Stone;


import java.util.List;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        System.out.println("Welcome to Gomoku");
        System.out.println("==================");
        PlayerSelection p1 = new PlayerSelection();
        Gomoku g = null;
        Player s1;
        Player s2;
        s1 = p1.selectPlayer(1);
        s2 = p1.selectPlayer(2);
        System.out.println(s1.getName());
        System.out.println(s2.getName());
        System.out.println("(Randomizing)");
        g = new Gomoku(s1, s2);
        Scanner sc1 = new Scanner(System.in);
        System.out.print("Enter a row:");
        int row = sc1.nextInt();
        System.out.print("Enter a col:");
        int col = sc1.nextInt();
        Stone st = new Stone(row, col, g.isBlacksTurn());
        Result newStone=g.place(st);
        g.place(st);
        System.out.println(g.place(st));

    }
}
