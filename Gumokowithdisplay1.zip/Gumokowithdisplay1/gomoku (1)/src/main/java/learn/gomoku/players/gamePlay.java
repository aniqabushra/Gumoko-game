package learn.gomoku.players;

import learn.gomoku.game.Stone;

import java.util.Scanner;

public class gamePlay {
    Stone st;

    public Stone stonePlacement() {
        Scanner sc1 = new Scanner(System.in);
        System.out.print("Enter a row:");
        int row = sc1.nextInt();
        System.out.print("Enter a col:");
        int col = sc1.nextInt();
        st = new Stone(row, col, true);
        return st;

    }
}
