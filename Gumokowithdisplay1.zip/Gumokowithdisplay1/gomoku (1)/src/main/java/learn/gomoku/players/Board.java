package learn.gomoku.players;

import learn.gomoku.game.Gomoku;

public class Board {

    private final char[][] board = new char[Gomoku.WIDTH][Gomoku.WIDTH];

    public char[][] createBoard() {
        //Making one digit no into two digit no.
        for (int toprow = 1; toprow <= 15; toprow++) {
            if(toprow<=9){
                System.out.print("0"+toprow+" ");
            }
            else if(toprow>9){
                System.out.print(toprow+" ");
            }
        }
        System.out.println();

        for (int rows = 0; rows < Gomoku.WIDTH; rows++) {
            // System.out.print((rows + 1 + " "));
            for (int col = 0; col < Gomoku.WIDTH; col++) {
                board[rows][col]='-';
            }
        }
        return board;
    }
}
