package learn.gomoku.players;

import java.util.Scanner;

public class PlayerSelection {
    private final Scanner console = new Scanner(System.in);
    private HumanPlayer human;
    private RandomPlayer cpu;
    private Player pl;

    public Player selectPlayer(int playerNo) {
        int selection;
        System.out.println("player " + playerNo + " is:");
        System.out.println("1.Human player");
        System.out.println("2.Random player");
        System.out.print("Select [1-2]:");
        Scanner sc = new Scanner(System.in);
        selection = sc.nextInt();
        if (selection == 1) {
            Scanner s = new Scanner(System.in);
            System.out.print("Player " + playerNo + ", enter your name:");
            String humanUserName = s.nextLine();

            HumanPlayer h1 = new HumanPlayer(humanUserName);
            pl = h1;
        } else if (selection == 2) {
            RandomPlayer r1 = new RandomPlayer();
            pl = r1;
        }
        return pl;

    }


}
